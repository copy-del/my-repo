// let like = like.addEventListener("click", function(){
//     let num = parseInt(ppp.innerHTML);
//     num +=1; 
//     ppp.innerHTML = num; 
// })

// let dislike = dislike.addEventListener("click",function(){
//     let num = parseInt(ppp.innerHTML);
//     if(num > 0){ 
//         num -= 1;
//         ppp.innerHTML = num; 
//     }
// })

// let chogihwa = chogihwa.addEventListener("click",function(){
// ppp.innerHTML = 0;
// })