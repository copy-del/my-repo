let for_gugudan = function(a){
    print('for문을 이용한 구구단')
    for(let i=0; i<9;i++){
        let result = (a,'x',i,'=',(a*i))
        
    }
}

let while_gugudan = function(a){
    print('while문을 이용한 구구단')
    i = 0;
    while(i<10)
        result = (a,'x',i,'=',(a*i))
        i++;
    }

